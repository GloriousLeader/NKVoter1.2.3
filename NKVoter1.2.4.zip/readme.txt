To run, use the LaunchApplet.html under the put_this_shit_on_the_server directory
if it doesn't work at first (it just freezes with the java logo or something), try refreshing the page
Also, the applet will print out "Updating voteamounts" numerous times between the 10-minute anti-ban delays; this is perfectly normal




To run either enter:
	java -jar VoteFucker.jar
from the command line, or just run the run.bat or run.sh file

If you want it to, this bot will try to use Tor for its connections,
if you already have tor up and running at 127.0.0.1, it will most likely succeed.

If it doesn't succeed, it will just use your regular ip for connections.

