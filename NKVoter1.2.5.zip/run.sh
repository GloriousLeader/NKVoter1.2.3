# Created by Sini
java -cp ./build/classes net.votefucker.nkvoter.Main
