#!/bin/bash
exec tor &
sleep 10 
./run.sh &
sleep 300
sudo pkill -9 tor &
sudo pkill -9 java &
./torrape.sh


